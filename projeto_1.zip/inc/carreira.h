#ifndef CARREIRA_H_
#define CARREIRA_H_

int carreira_encoder(short ** result, short * buffer, int size);
int carreira_decoder(short ** result, short * buffer, int size);

#endif