#ifndef DIFERENCA_H_
#define DIFERENCA_H_

short * diferenca_encoder(short * buffer, int size);
short * diferenca_decoder(short * buffer, int size);

#endif